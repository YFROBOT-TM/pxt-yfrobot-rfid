#include "nrf.h"

// helpful define to handle C++ differences in package
#define PXT_MICROBIT_TAGGED_INT 1
#define PXT_POWI 1
